﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;
using System.Xml.Linq;
using System.Reflection.PortableExecutable;
using System.Diagnostics.SymbolStore;
using System.Runtime.CompilerServices;

namespace ProjectZoo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. Добавяне  на ново животно:");
            Console.WriteLine("2. Промяна на статуса на наличност:");
            Console.WriteLine("3. Проверка на наличността и информация за животното:");
            Console.WriteLine("4. Справка за всички животни:");
            Console.WriteLine("Избор на опция:");
            MenuPrint();
           
        }
        static void MenuPrint()
        {
            
            string choice = Console.ReadLine();
          
            switch (choice)
            {
                case "1":
                    AddAnimal();
                    break;
                case "2":
                   

                    break;
                    case "3":

                    break;
                    case "4":

                    break; 
               
                default:
                    break;
            }
            
           static void AddAnimal()
            {
                StreamReader read = new StreamReader("animals.txt");
                string line;
                string info = read.ReadToEnd();
                while ((line = read.ReadLine()) != null)
                {

                    Console.WriteLine(line);
                }
                string newAnimalInfo = Console.ReadLine();
                read.Close();
                StreamWriter write = new StreamWriter("output.txt");
                using (write)
                {

                    write.WriteLine(info);
                    write.WriteLine(newAnimalInfo);

                }


            }



        }
    }
}
